# GoogleMapDirectionSimple
Create a simple app that find routes between two places base on their address text on Google Map using Google Map Direction API

![Demo Image][1]


[1]:https://raw.githubusercontent.com/hiepxuan2008/GoogleMapDirectionSimple/master/screenshots/1.jpg
